Welcome to Fantasy Cricket Game
The game has been built on PyQt5 framework and uses sqlite3 for data sourcing.
So please make sure that you have the following install on your system:
1. Python3
To install Python3, go to this link: https://www.python.org/ftp/python/3.6.8/python-3.6.8-amd64.exe
and download the prompted files and add python to path variable

2. pyqt5
To install pyqt5 you need to have python version >= 3 installed
If python is installed:
	1.Press 'Windows key'+'R' on your keyboard
	2.Type cmd and press enter
	3.Type the following command and install the prompted files:
	pip install PyQt5

3.sqlite3
If python is installed:
	1.Press 'Windows key'+'R' on your keyboard
	2.Type cmd and press enter
	3.Type the following command and install the prompted files:
	pip install db-sqlite3

INSTRUCTIONS:
1. To run the game execute driver.py.

2. If you want to clear the list of saved teams then run the file named 'init_table.py'

